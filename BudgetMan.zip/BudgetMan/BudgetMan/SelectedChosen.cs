﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetMan
{
    class SelectedChosen
    {
        public string ID { get; set; }
        public string BudgetName { get; set; }
        public string Beskrivelse { get; set; }
        public string Bruger { get; set; }
    }
}
