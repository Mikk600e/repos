﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetMan
{
    /// <summary>
    /// Interaction logic for FinanceCreate.xaml
    /// </summary>
    public partial class FinanceCreate : Window
    {
        public FinanceCreate(string ID, string Name, string Bruger, string Beskrivelse)
        {
            SelectedChosen rnd = new SelectedChosen();
            InitializeComponent();
            IDTxt.Content = ID;
            NameTxt.Content = Bruger;
            BeskrivelseTxt.Content = Beskrivelse;
            BrugerTxt.Content = Bruger;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        
        private void SavePost_Click(object sender, RoutedEventArgs e)
        {
            FinanceGroup NewPost = new FinanceGroup(SaveName.Text, PostRel.Text);
            Database.AddPost(NewPost);
            SaveName.Clear();
            PostRel.Clear();
        }
    }
}
