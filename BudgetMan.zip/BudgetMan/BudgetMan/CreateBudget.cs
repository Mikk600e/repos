﻿using BudgetMan;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetMan
{
    class CreateBudget
    {
        public static void FreshBudget(string IDUsrStr, string BudgetNameStr, string BeskrivelseStr, string BrugerStr)
        {
            Budget NewBudget = new Budget(IDUsrStr, BudgetNameStr, BeskrivelseStr, BrugerStr);
            //Budget.EnterBudget(IDUsrStr, BudgetNameStr, BeskrivelseStr, BrugerStr);
            Database.Create(NewBudget);
        }


    }
}
