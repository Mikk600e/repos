﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetMan
{
    class FinanceGroup
    {
        public string Name { get; set; }
        public string Inflydelse { get; set; }
        public FinanceGroup(string NameUsr, string RelationUsr)
        {
            Name = NameUsr;
            Inflydelse = RelationUsr;
        }
    }
}
