﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetMan
{
    class Database
    {
        public static void Create(Budget NewBudget)
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection("Data Source=.;Initial Catalog=BudgetMan;Integrated Security=true");
                SqlCommand cmd = new SqlCommand(string.Format
                ("INSERT INTO Budgets (ID, BudgetName, Beskrivelse, Bruger) VALUES ('{0}', '{1}', '{2}', '{3}')",
                NewBudget.ID, NewBudget.BudgetName, NewBudget.Beskrivelse, NewBudget.Bruger), connection);
                connection.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static List<Budget> ShowAllBudgets()
        {
            List<Budget> budgetList = new List<Budget>();
            connection = new SqlConnection("Data Source=.;Initial Catalog=BudgetMan;Integrated Security=true");
            connection.Open();
            SqlCommand getBudgets = new SqlCommand("SELECT * FROM Budgets", connection);
            SqlDataReader reader = getBudgets.ExecuteReader();
            while (reader.Read())
            {
                Budget bud = new Budget();
                bud.ID = reader.GetString(0);
                bud.BudgetName = reader.GetString(1);
                bud.Beskrivelse = reader.GetString(2);
                bud.Bruger = reader.GetString(3);
                budgetList.Add(bud);
            }
            CloseConnection();

                return budgetList;
        }

        public static void AddPost(FinanceGroup NewPost)
        {
            SqlConnection connection = null;
            try
            { 
                connection = new SqlConnection("Data Source=.;Initial Catalog=BudgetMan;Integrated Security=true");
                SqlCommand cmd = new SqlCommand(string.Format
                ("INSERT INTO FinansGruppe (Navn, Indflydelse, BudgetID) VALUES ('{0}', '{1}', '{2}')",
                NewPost.Name, NewPost.Inflydelse), connection);
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
        }

        static SqlConnection connection;
        public static void OpenConnection()
        {
            try
            {
                connection = new SqlConnection("Data Source=.;Initial Catalog=BudgetMan;Integrated Security=true");
            }
            catch (Exception)
            {

                throw;
            }
        }
        private static void CloseConnection()
        {
            connection.Close();
        }
    }
}

