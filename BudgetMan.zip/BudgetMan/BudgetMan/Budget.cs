﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetMan
{
    class Budget
    {
        public string ID{ get; set; }
        public string BudgetName { get; set; }
        public string Beskrivelse { get; set; }
        public string Bruger { get; set; }
        public Budget(string IDUsrStr, string BudgetNameStr, string BeskrivelseStr, string BrugerStr)
        {
            ID = IDUsrStr;
            BudgetName = BudgetNameStr;
            Beskrivelse = BeskrivelseStr;
            Bruger = BrugerStr;  
        }
        public Budget()
        {
            ID = "";
            BudgetName = "";
            Beskrivelse = "";
            Bruger = "";
        }
        public override string ToString()
        {
            return string.Format("Navn: {0}\t ID: {1}\nBeskrivelse: {2}", BudgetName, ID, Beskrivelse);
        }
    }
}
