﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetMan
{
    /// <summary>
    /// Interaction logic for NewBudget.xaml
    /// </summary>
    public partial class NewBudget : Window
    {
        public NewBudget()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //OKBtn.Content = IDStr.Text;
            CreateBudget.FreshBudget(IDStr.Text, BudgetName.Text, Beskrivelse.Text, Bruger.Text);
            this.Close();
        }
    }
}
