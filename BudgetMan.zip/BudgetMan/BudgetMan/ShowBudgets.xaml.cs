﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BudgetMan
{
    /// <summary>
    /// Interaction logic for ShowBudgets.xaml
    /// </summary>
    public partial class ShowBudgets : Window
    {
        public ShowBudgets()
        {
            InitializeComponent();
            List<Budget> items = Database.ShowAllBudgets();
            listbox_budget.ItemsSource = items;
        }
        private void listbox_budget_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Budget chosen = (Budget)listbox_budget.SelectedItem;
            SelectedChosen selectedChosen = new SelectedChosen();
            selectedChosen.ID = chosen.ID;
            selectedChosen.BudgetName = chosen.BudgetName;
            selectedChosen.Bruger = chosen.Bruger;
            selectedChosen.Bruger = chosen.Beskrivelse;
            FinanceBudget.SelectedBudget = chosen;
            FinanceCreate create = new FinanceCreate(chosen.ID, chosen.BudgetName, chosen.Bruger, chosen.Beskrivelse);
            create.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
